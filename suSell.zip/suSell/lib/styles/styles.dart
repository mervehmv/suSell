import 'package:flutter/material.dart';
import 'package:susell/colors/colors.dart';
import 'package:google_fonts/google_fonts.dart';


const appBarTitleStyle = TextStyle(
  color: AppColors.headingColor,
  fontWeight: FontWeight.w900,
  fontSize: 20.0,
  letterSpacing: -0.7,
);

const profileName = TextStyle(
  color: AppColors.buttomNavigator,
  fontWeight: FontWeight.w900,
  fontSize: 18.0,
  letterSpacing: -0.7,
);

const kButtonLightTextStyle = TextStyle(
  color: Colors.black,
  fontSize: 20.0,
  letterSpacing: -0.7,
);

const kButtonDarkTextStyle = TextStyle(
  color: Colors.black,
  fontSize: 20.0,
  letterSpacing: -0.7,
);

const kButtonWhiteTextStyle = TextStyle(
  color: Colors.white,
  fontSize: 20.0,
  letterSpacing: -0.7,
);

const imageCaptionStyle = TextStyle(
  color: Colors.white,
  fontSize: 24.0,
  fontWeight: FontWeight.w600,
  letterSpacing: -0.7,
);

const pageStyle = TextStyle(
  color: Colors.indigo,
  fontSize: 24.0,
  fontWeight: FontWeight.w600,
  letterSpacing: -0.7,
);

final kCyanTitleTextStyle = TextStyle(
  color: Colors.indigo,
  fontSize: 24.0,
  fontWeight: FontWeight.w600,
  letterSpacing: -0.7,
);

final pageTitleStyle = GoogleFonts.montserrat(
  fontSize: 32,
  fontWeight: FontWeight.w800,
  letterSpacing: -1,
  color: AppColors.pageTitleC,
);

final pageTitleStyle1 = GoogleFonts.montserrat(
  fontSize: 32,
  fontWeight: FontWeight.w800,
  letterSpacing: -1,
  color: AppColors.primary,
);