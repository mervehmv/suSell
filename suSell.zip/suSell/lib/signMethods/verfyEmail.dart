import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';


class verifyMail extends StatefulWidget {
  const verifyMail({Key? key}) : super(key: key);

  @override
  _verifyMailState createState() => _verifyMailState();
}

class _verifyMailState extends State<verifyMail> {


  final auth = FirebaseAuth.instance;
  late User user;
  late Timer timer;


  @override
  void initState() {
    user = auth.currentUser!;
    user.sendEmailVerification();

    Timer.periodic(Duration(seconds: 5), (timer) {
      checkVerified();
    });
    super.initState();
  }

  Future<void> checkVerified() async {
    user = auth.currentUser!;
    await user.reload();
    if(user.emailVerified){
      timer.cancel();
      Navigator.of(context).pushReplacementNamed('/feed');
    }
  }


  @override
  void dispose() {
    timer.cancel();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:
        Center(
          child: Text('Email has sent to ${user.email} please verify'),
        ),
    );
  }
}


